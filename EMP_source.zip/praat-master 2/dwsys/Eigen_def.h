/* Eigen_def.h
 *
 * Copyright (C) 1993-2008 David Weenink
 *
 * This code is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This code is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this work. If not, see <http://www.gnu.org/licenses/>.
 */

#define ooSTRUCT Eigen
oo_DEFINE_CLASS (Eigen, Daata)

	oo_LONG (numberOfEigenvalues)
	oo_LONG (dimension)
	oo_DOUBLE_VECTOR (eigenvalues, numberOfEigenvalues)
	oo_DOUBLE_MATRIX (eigenvectors, numberOfEigenvalues, dimension)

oo_END_CLASS (Eigen)
#undef ooSTRUCT

/* End of file Eigen_def.h */
